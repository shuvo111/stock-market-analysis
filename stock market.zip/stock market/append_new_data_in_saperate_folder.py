import csv
import os

global a, b, e, g, str4, str2, counter
a = []
b = []
e = []
g = []
str4 = ""
str2 = ""
counter = 0

# field names
fields = ['Name', 'Date', 'A', 'B', 'C', 'D', 'E']


def write(b, str2):
    stri = str(str2)
    filename = "C:/Users/USER/Desktop/stock exchange data/Saperate Company File/" + stri + ".csv"

    for x in range(len(b)):
        fields = b[x]
        with open(filename, 'a') as f:
            writer = csv.writer(f)
            writer.writerow(fields)
            fields = []


def read():
    for x in range(150):
        # opening the CSV file
        d = str(x)
        print(d)
        with open("C:/Users/USER/Desktop/stock exchange data/daily data/daily data/" + d + ".csv", mode='r')as file:
            # reading the CSV file
            csvFile = csv.reader(file)

            # displaying the contents of the CSV file
            for lines in csvFile:
                a.append(lines)

    str4 = a[0][0]
    e.append(a[0][0])
    for x in range(1, len(a)):
        if a[x][0] == str4:
            break
        else:
            e.append(a[x][0])
    for c in range(len(e)):
        b = []
        for x in range(len(a)):
            if a[x][0] == e[c]:
                str2 = str(e[c])
                b.append(a[x])
        write(b, str2)
        global counter
        counter += 1
        zz = str(counter)
        print(zz+" done")


read()
