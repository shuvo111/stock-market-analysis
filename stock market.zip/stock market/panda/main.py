import pandas as pd
import csv
import os
import datetime

global a, b, c, str2, str1, str3, Date, Open_price, High_price, Low_price, Close_price, Volume, Da, O_P, H_P, L_P, C_P, Vo
str2 = ""
str1 = ""
str3 = ""
Date = ""
Open_price = ""
High_price = ""
Low_price = ""
Close_price = ""
Volume = ""
b = []
a = []
c = []
Da = []
O_P = []
H_P = []
L_P = []
C_P = []
Vo = []


def write(df, str3):
    d = str(str3)
    df.to_csv("C:/Users/USER/Desktop/stock exchange data/Panda_Data_Set/" + d + ".csv", index=False)
    df = pd.DataFrame(
        {'Date': [], 'Open_price': [], 'High_price': [], 'Low_price': [], 'Close_price': [], 'Volume': []})
    print("------------- " + d + " ---------Done")


def date(ax):
    b = str(ax)
    for x in range(len(b)):
        if b[x] == '-':
            dt = datetime.datetime.strptime(b, '%d-%m-%Y')
            return '{0}/{1}/{2:02}'.format(dt.month, dt.day, dt.year % 100)
        elif b[x] == '/':
            dt = datetime.datetime.strptime(b, '%d/%m/%Y')
            return '{0}/{1}/{2:02}'.format(dt.month, dt.day, dt.year % 100)


def read3(c, str3):
    global Da, O_P, H_P, L_P, C_P, Vo
    Da = []
    O_P = []
    H_P = []
    L_P = []
    C_P = []
    Vo = []
    for lines in c:
        Date = date(str(lines[1]))
        Da.append(Date)

        Open_price = lines[2]
        O_P.append(Open_price)

        High_price = lines[3]
        H_P.append(High_price)

        Low_price = lines[4]
        L_P.append(Low_price)

        Close_price = lines[5]
        C_P.append(Close_price)

        Volume = lines[6]
        Vo.append(Volume)

    # make DataSet
    list_of_tuples = list(zip(Da, O_P, H_P, L_P, C_P, Vo))
    df = pd.DataFrame(list_of_tuples,
                      columns=['Date', 'Open_price', 'High_price', 'Low_price', 'Close_price', 'Volume'])
    write(df, str3)


def read2(a, str3):
    global c
    c = []
    for x in range(len(a)):
        if a[x] == []:
            continue
        else:
            c.append(a[x])
    read3(c, str3)


def read1(str3):
    global a
    a = []
    d = str(str3)
    with open("C:/Users/USER/Desktop/stock exchange data/Saperate Company File/" + d + ".csv", mode='r')as file:
        # reading the CSV file
        csvFile = csv.reader(file)

        # displaying the contents of the CSV file
        for lines in csvFile:
            a.append(lines)
    read2(a, str3)


def read():
    arr = os.listdir('C:/Users/USER/Desktop/stock exchange data/Saperate Company File')
    for x in arr:
        str1 = str(x)
        for x in range(len(str1)):
            if str1[x] == '.':
                break
            else:
                aa = str(str1[x])
                global str2
                str2 = str2 + aa
        b.append(str2)
        str2 = ""
    for x in range(len(b)):
        str3 = str(b[x])
        read1(str3)


read()
