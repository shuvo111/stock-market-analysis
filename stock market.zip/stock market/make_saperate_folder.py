import csv
import os

global a, b, e, f, c, str4, str2, counter
a = []
b = []
e = []
f = []
c = 1
str4 = ""
str2 = ""
counter = 0

# field names
fields = ['Name', 'Date', 'Opening Price', 'High Price', 'Low Price', 'Closing Price', 'Volume']


def write(str2):
    global c
    # name of csv file
    filename = "C:/Users/USER/Desktop/stock exchange data/Saperate Company File/" + str2 + ".csv"
    # writing to csv file
    with open(filename, 'w') as file:
        # creating a csv writer object
        csvwriter = csv.writer(file)

        # writing the fields
        if c == 1:
            csvwriter.writerow(fields)
            c += 1

        # writing the data rows
        global a
        csvwriter.writerows(a)
        a = []
        global counter
        counter += 1
        zz = str(counter)
        print(
            "----------" + str2 + "---------- file is ready! file number is ----------" + zz + "---------- Please check it out.")


def read(str2):
    for x in range(21):
        # opening the CSV file
        d = str(x)
        with open("C:/Users/USER/Desktop/stock exchange data/" + d + ".csv", mode='r')as file:
            # reading the CSV file
            csvFile = csv.reader(file)

            # displaying the contents of the CSV file
            for lines in csvFile:
                if lines[0] == str2:
                    a.append(lines)
    write(str2)


def Company_Name():
    def files(path):
        for file in os.listdir(path):
            if os.path.isfile(os.path.join(path, file)):
                yield file

    for file in files('C:/Users/USER/Desktop/stock exchange data/Saperate Company File'):
        e.append(file)

    with open("C:/Users/USER/Desktop/stock exchange data/20.csv", mode='r')as file:
        # reading the CSV file
        csvFile = csv.reader(file)
        # displaying the contents of the CSV file
        for lines in csvFile:
            str1 = lines
            b.append(str1)
    for n in range(len(e)):
        global str4
        str3 = (e[n])
        for x in str3:
            if x == ".":
                f.append(str4)
                str4 = ""
                break
            else:
                str4 = str4 + x
    for m in range(len(b)):
        if b[m][0] == "zzzzz":
            break
        else:
            if b[m][0] != b[m + 1][0]:
                global str2
                str2 = b[m][0]
                for xx in f:
                    if str2 == xx:
                        continue
                    else:
                        read(str2)
                        break
            else:
                continue


write("shuvo")
Company_Name()
